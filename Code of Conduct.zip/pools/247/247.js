window.CPPool247Init = function() { cp.model['247Data']={
};cp.model.data['247']={
pqs:[],
gqs:[],
sqs:[],
rgqs:[],
rsqs:[],
hasCC:false
};
cp.poolResources["247Images"]=[];
cp.poolResources["247Videos"]=[
];
cp.poolResources["247SlideVideos"]=[
];
}